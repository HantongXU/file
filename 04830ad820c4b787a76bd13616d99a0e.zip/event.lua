local gRealTimerId = 316914
local init_state = 1

-------------------------- server algorithm begin --------------------------
local PixelFormat = {
    RGBA = 0,
    BGRA = 1,
    BGR = 2,
    RGB = 3,
    GRAY = 4
}

local CVType = {
    CV_8UC1 = 0,
    CV_8UC3 = 16,
    CV_8UC4 = 24
}

local function pixelFormat2CVType(pixelFormat)
    if pixelFormat == PixelFormat.RGBA or pixelFormat == PixelFormat.BGRA then
        return CVType.CV_8UC4
    elseif pixelFormat == PixelFormat.RGB or pixelFormat == PixelFormat.BGR then
        return CVType.CV_8UC3
    elseif pixelFormat == PixelFormat.GRAY then
        return CVType.CV_8UC1
    else
        return -1
    end
end

-- FrameUploader begin
FrameUploader = {
    -- detect product url
    url = "https://aweme.snssdk.com/media/api/scan/detect/",
    -- url = "http://effect.boe.bytedance.net/media/api/scan/detect/",
    -- input image width expected by algorithm
    width = 0,
    -- input image height expected by algorithm
    height = 0,
    -- input image format expected by algorithm
    format = PixelFormat.RGBA
}

function FrameUploader:new(o, width, height, format)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    self.width = width or 0
    self.height = height or 0
    self.format = format or PixelFormat.RGBA
    return o
end

function FrameUploader:vaild()
    return self.width > 0 and self.height > 0 and self.format >= PixelFormat.RGBA and self.format <= PixelFormat.GRAY
end

function FrameUploader:getAppropriateScale(originWidth, originHeight)
    local scale = math.min(originWidth / self.width, originHeight / self.height)
    if scale < 1 then
        scale = 1
    end
    return scale
end

function FrameUploader:upload(texture)
    local originWidth = texture:getWidth()
    local originHeight = texture:getHeight()
    local scale = self:getAppropriateScale(originWidth, originHeight)
    -- append rows/cols/type
    local scaledWidth = originWidth / scale
    local scaledHeight = originHeight / scale
    local finalWidth = math.floor(scaledWidth * 0.8)
    local finalHeight = finalWidth
    local cropArea =
        EffectSdk.Viewport((scaledWidth - finalWidth) / 2, (scaledHeight - finalHeight) / 2, finalWidth, finalHeight)

    local conf = {rows = finalHeight, cols = finalWidth, type = pixelFormat2CVType(self.format)}
    -- local groupidConf = {groupids = 'ggl_orb_07162021'}
    local finalUrl = self.url .. "?conf=" .. json.encode(conf) .. '&groupids=ggl_orb_07162021'
    print("fanxiangyu url is "..finalUrl)

    local headerMap = EffectSdk.MapSS()
    -- Content-Type set in C++
    headerMap:set("Content-Type", "application/octet-stream")
    return EffectSdk.uploadImageByTexture(finalUrl, headerMap, true, texture, self.format, scale, cropArea)
end

-- best call in handleBeforeRender
function FrameUploader:uploadCurSrcTexture(this)
    local effectManager = this:getEffectManager()
    if effectManager then
        local srcTexture = effectManager:getCurSrcTexture()
        if srcTexture then
            return self:upload(srcTexture)
        end
    end
    return 0
end

-- FrameUploader end

local function loadJson(this, featureName)
    local feature = this:getFeature(featureName)
    if feature then
        local featureAbsPath = feature:getAbsPath()
        json = loadfile(featureAbsPath .. "/../json.lua")()
    end
end

local function isJsonVaild(str)
    local first = string.sub(str, 1, 1)
    local last = string.sub(str, -1)
    return (first == "{" and last == "}") or (first == "[" and last == "]")
end

local function parseProductList(responseBody)
    if isJsonVaild(responseBody) then
        local result = json.decode(responseBody)

        if result.status_code == 0 and result.data ~= nil and result.data.list ~= nil and #result.data.list > 0 then
            local productList = result.data.list
            for i = 1, #productList do
                -- priority may be nil
                productList[i].priority = productList[i].priority or 0
            end
            return productList
        else
            EffectSdk.LOG_LEVEL(8, "yangxuefeng parseProductList fail")
        end
    end

    return {}
end

local function getTimeStamp(this)
    local effectManager = this:getEffectManager()
    if effectManager then
        return effectManager:getTimeStamp()
    end
    return 0
end

local needStop = false
local function detectProduct(product_id)
    if product_id == 87 then
        EffectSdk.MessageCenter.postMessage(
            EffectSdk.RENDER_MSG_TYPE_ARSCAN,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_ALGORITHM,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_TRACKED,
            "{\"product_id\": \"1189222\"}"
        )
    elseif product_id == 88 then
        EffectSdk.MessageCenter.postMessage(
            EffectSdk.RENDER_MSG_TYPE_ARSCAN,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_ALGORITHM,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_TRACKED,
            "{\"product_id\": \"1189416\"}"
        )
    elseif product_id == 89 then
        EffectSdk.MessageCenter.postMessage(
            EffectSdk.RENDER_MSG_TYPE_ARSCAN,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_ALGORITHM,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_TRACKED,
            "{\"product_id\": \"1208572\"}"
        )
    elseif product_id == 90 then
        EffectSdk.MessageCenter.postMessage(
            EffectSdk.RENDER_MSG_TYPE_ARSCAN,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_ALGORITHM,
            EffectSdk.RENDER_MSG_TYPE_ARSCAN_TRACKED,
            "{\"product_id\": \"1201696\"}"
        )
    else
        return
    end
    needStop = true
end

local uploadFrame = false
local frameUploader = nil
local curRequestID = -1
local lastUploadTime = 0
-- 1s per frame, when cost time of upload less than 1s
local uploadFrequency = 1.0
local lastDetectedTime = 0
local detectTimeout = 15
local lastRequestTime = 0
local requestTimeout = 10
-------------------------- server algorithm end --------------------------

local justReturnEntranceCnt = -1

EventHandles = {
    handleEffectEvent = function(this, eventCode)
        if (init_state == 1 and eventCode == 1) then
            init_state = 0
            print('fanxiangyu, onStart')

            loadJson(this, "GrabHistogram")
            frameUploader = FrameUploader:new(nil, 540, 960, PixelFormat.RGBA)
            uploadFrame = true
            lastDetectedTime = getTimeStamp(this)
            lastUploadTime = lastDetectedTime
        end
        return true
    end,
    handleUpdate = function(this, timestamp)
        if init_state ~= 0 then
            return true
        end

        -- detect timeout
        if timestamp - lastDetectedTime > detectTimeout then
            EffectSdk.MessageCenter.postMessage(EffectSdk.BEF_MSG_TYPE_GENERAL_STATUS, 1, 1, "")
            lastDetectedTime = timestamp
        -- showText(this, "long time no detect")
        end

        -- request timeout
        if timestamp - lastUploadTime > requestTimeout then
            uploadFrame = true
        -- showText(this, "request timeout")
        end

        return true
    end,
    handleBeforeRender = function(this, timestamp)
        if (init_state ~= 0 or not uploadFrame or needStop) then
            return true
        end

        if timestamp - lastUploadTime < uploadFrequency then
            return true
        end

        curRequestID = frameUploader:uploadCurSrcTexture(this)
        if curRequestID ~= 0 then
            uploadFrame = false
            lastUploadTime = timestamp
        end

        return true
    end,
    handleNetworkResponseEvent = function(this, status, requestID, responseBody)
        EffectSdk.LOG_LEVEL(8, "yangxuefeng handleNetworkResponseEvent network Status " .. status)
        EffectSdk.LOG_LEVEL(8, "yangxuefeng handleNetworkResponseEvent network requestID " .. requestID)
        EffectSdk.LOG_LEVEL(8, "yangxuefeng handleNetworkResponseEvent network responseBody " .. responseBody)
        if init_state ~= 0 and requestID == curRequestID then
            return true
        end

        if status == 2 then
            local productList = parseProductList(responseBody)
            for i = 1, #productList do
                EffectSdk.LOG_LEVEL(8, "yangxuefeng " .. i)
                EffectSdk.LOG_LEVEL(8, "yangxuefeng " .. productList[i].product_id)
                detectProduct(productList[i].product_id)
            end

            if #productList > 0 then
                lastDetectedTime = getTimeStamp(this)
            end
        end

        -- showText(this, info)
        if status == 2 or status == 3 then
            uploadFrame = true
        -- curRequestID = frameUploader:uploadCurSrcTexture(this)
        end
        return true
    end,
    -- handleObjectTrackEvent = function(this, objectTrackInfo)
    --     if init_state ~= 0 then
    --         return true
    --     end

    --     local trackStatus = objectTrackInfo:getStatus()
    --     local objectId = objectTrackInfo:getObjectId()

    --     if trackStatus == 1 then
    --         if objectId == 9 then
    --             detectProduct("jiashu")
    --         else
    --             detectProduct("")
    --         end
    --     end
    -- end
}
